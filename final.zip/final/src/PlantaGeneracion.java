
public class PlantaGeneracion {
private int id;
private String recurso;
private String ciudad;
private String fechainicial;
private Double factordedisponibilidad;
private Double presupuestomantenimiento;
public PlantaGeneracion(int id, String recurso, String ciudad, String fechainicial, Double factordedisponibilidad,
		Double presupuestomantenimiento) {
	super();
	this.id = id;
	this.recurso = recurso;
	this.ciudad = ciudad;
	this.fechainicial = fechainicial;
	this.factordedisponibilidad = factordedisponibilidad;
	this.presupuestomantenimiento = presupuestomantenimiento;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getRecurso() {
	return recurso;
}
public void setRecurso(String recurso) {
	this.recurso = recurso;
}
public String getCiudad() {
	return ciudad;
}
public void setCiudad(String ciudad) {
	this.ciudad = ciudad;
}
public String getFechainicial() {
	return fechainicial;
}
public void setFechainicial(String fechainicial) {
	this.fechainicial = fechainicial;
}
public Double getFactordedisponibilidad() {
	return factordedisponibilidad;
}
public void setFactordedisponibilidad(Double factordedisponibilidad) {
	this.factordedisponibilidad = factordedisponibilidad;
}
public Double getPresupuestomantenimiento() {
	return presupuestomantenimiento;
}
public void setPresupuestomantenimiento(Double presupuestomantenimiento) {
	this.presupuestomantenimiento = presupuestomantenimiento;
}

}
