import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n=8;
int m=8;
AgenteMercado  AgenteMercado[]=new  AgenteMercado[n];
PlantaGeneracion[]grupo1=new PlantaGeneracion[m];
PlantaGeneracion[]grupo2=new PlantaGeneracion[m];
PlantaGeneracion[]grupo3=new PlantaGeneracion[m];
/*long id, String nombre, PlantaGeneracion[] plantageneracion, String ciudad, String presidente,
		Double dinerodisponible*/
grupo1[0]= new PlantaGeneracion(20,"carbon","madrid","22/07/2020",6564.56576,65645.543);
grupo1[1]= new PlantaGeneracion(37,"nuclear","bogota","14/03/2018",43.15,150000.1);
grupo1[2]= new PlantaGeneracion(25,"carbon","munchen","34/04/2010",84858346.12,148856.75);
grupo1[3]= new PlantaGeneracion(28,"nuclear","moscow","20/05/2011",37524.1,23143.1);
grupo1[4]= new PlantaGeneracion(4,"carbon","lopital","30/02/2012",2423425.1,32467.1);
grupo1[5]= new PlantaGeneracion(8,"nuclear","mochis","03/07/2013",3546.1,65645.543);
grupo1[6]= new PlantaGeneracion(3,"carbon","madrid","18/08/2014",67435.1,6784523.1);
grupo1[7]= new PlantaGeneracion(32,"nuclear","tokio","02/09/2015",65237624.1,35434647.3);

AgenteMercado[0]= new AgenteMercado(52,"avestruz",grupo1, "madrid","carlos",540000000.1);
AgenteMercado[1]= new AgenteMercado(23,"gloves",grupo1, "medellin","laura",670000000.1);
AgenteMercado[2]= new AgenteMercado(87,"gas",grupo1, "cucuta","perry",870000000.1);
AgenteMercado[3]= new AgenteMercado(45,"amo�os",grupo1, "bogota","alberto",340000000.1);
AgenteMercado[4]= new AgenteMercado(98,"avestruz.2",grupo1, "guadalajara","clara",260000000.1);
AgenteMercado[5]= new AgenteMercado(34,"programcionlomejor",grupo1, "pasto","juan",860000000.1);
AgenteMercado[6]= new AgenteMercado(65,"lopanianm",grupo1, "amazonas","rodolfo",240000000.1);
AgenteMercado[7]= new AgenteMercado(14,"fgfhdghdf",grupo1, "tutucan","sofia",790000000.1);

Scanner linea=new Scanner(System.in);
int opcion=0;
while(true) {
	System.out.println("ingrese una opcion");
	System.out.println("1. listar empresas");
	System.out.println("2. id");
	System.out.println("3. ciudad");
	System.out.println("4.presidente");
	System.out.println("5. dinero disponible");
	System.out.println("6. salir");
	opcion=linea.nextInt();
	if(opcion==1) {
		
	}
	else if(opcion==2);{
		for(AgenteMercado empresa:AgenteMercado) {
	System.out.println(empresa);
		}
	 if(opcion==3);{
		
	}
	  if(opcion==4);{
		 
	 }
		if(opcion==5); {
			
		}
		if (opcion==6);{
			System.out.println("adios");
		}
		 if(opcion>6) {
			System.out.println("ingrese una opcion valida");
		}
	}
}

}


